#!/bin/bash
# Helper script to initialize git and push to a new GitHub repo.
# Usage: ./push_to_github.sh <GITHUB_REMOTE_URL> "<commit message>"
set -e
if [ -z "$1" ]; then
  echo "Usage: $0 <GITHUB_REMOTE_URL> \"<commit message>\""
  exit 1
fi
REMOTE="$1"
MSG="${2:-Initial commit}"
git init
git add .
git commit -m "$MSG"
git branch -M main || true
git remote add origin "$REMOTE"
git push -u origin main
